/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*\
    Filename: scripts.js
    Written by: Elizabeth Weisbrod
\*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/

