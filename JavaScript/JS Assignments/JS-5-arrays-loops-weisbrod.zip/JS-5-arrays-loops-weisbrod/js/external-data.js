// ARRAYS
let barnyardAnimals = ['Sheep', 'Cow', 'Chicken', 'Pig', 'Horse', 'Donkey'];
let songTitles = ['Stairway to Heaven', 'November Rain', 'The Hellion / Electric Eye', 'Bat Country'];

// JSON
let products = {
    'product1': {
        'name': 'Coca-Cola',
        'price': 5.37,
        'type': 'Beverage'
    },
    'product2': {
        'name': 'Doritos',
        'price': 4.42,
        'type': 'Chips'
    },
    'product3': {
        'name': 'Oreo',
        'price': 3.91,
        'type': 'Biscuit'
    },
    'product4': {
        'name': 'Jif',
        'price': 2.85,
        'type': 'Peanut Butter Spread'
    }
}