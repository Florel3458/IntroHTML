/*  JavaScript 7th Edition
    Chapter 1
    Hands-On Project 1-2

    Author: Elizabeth Weisbrod
    Date:   2021/10/26

    Filename: project01-02.js
*/

//define variables for service name and service speed
var service1Name = "Basic"
var service2Name = "Express"
var service3Name = "Extreme"
var service4Name = "Ultimate"
var service1Speed = "50 Mbps"
var service2Speed = "100Mbps"
var service3Speed = "500 Mbps"
var service4Speed = "1 Gig"