/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*\
    Filename: scripts.js
    Written by: Elizabeth Weisbrod
\*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/

//It looks rather empty here...